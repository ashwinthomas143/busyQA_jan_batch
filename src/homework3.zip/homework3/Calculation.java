package homework3;
//Provided by Thomas Ashwin Varghese
// To BusyQA - Simran and Harsha

public class Calculation {

    int sum;
    double sum1;

    public Calculation(int x, int y) {
        sum = x + y;
    }

    public Calculation(int x, int y, int z) {
        sum = x + y + z;
    }

    public Calculation(double x, double y) {
        sum1 = x + y;
    }

    public Calculation(double x, double y, double z) {
        sum1 = x + y + z;
    }


}
